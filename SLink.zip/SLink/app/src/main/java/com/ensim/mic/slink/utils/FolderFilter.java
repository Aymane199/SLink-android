package com.ensim.mic.slink.utils;

public enum FolderFilter {
     FILTER_ANYONE,
     FILTER_OWNED_BY_ME,
     FILTER_SHARED_WITH_ME,
     FILTER_SUBSCRIPTION
}
