package com.ensim.mic.slink.State;

public interface OnChangeObject {

    void onLoading();

    void onDataReady();

    void onFailed();

}
