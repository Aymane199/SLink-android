package com.ensim.mic.slink.utils;

public enum RequestState {
    SUCCESSFUL,
    FAILED,
    LOADING
}
